package com.empresa.mspersonclient.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.UuidGenerator;

import java.util.UUID;

@Data
@Entity
@Table(name = "clientes")
@EqualsAndHashCode(callSuper = true)
public class Client extends Person {



    @Column(nullable = false, unique = true)
    private String clienteId;

    @NotBlank(message = "La contraseña no puede estar vacía")
    private String contraseña;
    private boolean estado;

    @PrePersist
    private void generateClientId() {
        if (this.clienteId == null || this.clienteId.isBlank()) {
            this.clienteId = UUID.randomUUID().toString();
        }
    }

}