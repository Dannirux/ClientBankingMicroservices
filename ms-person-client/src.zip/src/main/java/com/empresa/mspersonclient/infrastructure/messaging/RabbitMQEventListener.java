package com.empresa.mspersonclient.infrastructure.messaging;

import com.empresa.mspersonclient.domain.events.ClientDeletedEvent;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class RabbitMQEventListener {



    @RabbitListener(queues = RabbitMQConfig.CLIENT_DELETED_QUEUE)
    public void handleClientDeletedEvent(ClientDeletedEvent event) {
        System.out.println("Evento recibido: Cliente eliminado con ID " + event.getClientId());
    }
}
