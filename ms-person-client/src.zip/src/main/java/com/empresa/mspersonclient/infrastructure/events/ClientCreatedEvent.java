package com.empresa.mspersonclient.infrastructure.events;

public class ClientCreatedEvent {
}
