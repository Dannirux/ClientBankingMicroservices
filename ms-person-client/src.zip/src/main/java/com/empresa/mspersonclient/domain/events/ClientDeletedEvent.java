package com.empresa.mspersonclient.domain.events;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
public class ClientDeletedEvent extends CommonEvent {

    private final String clientId;

    public ClientDeletedEvent(String clientId) {
        super("ClientDeletedEvent");
        this.clientId = clientId;
    }
}