package com.empresa.mspersonclient.infrastructure.messaging;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String CLIENT_EXCHANGE = "client.exchange";
    public static final String CLIENT_CREATED_QUEUE = "client-created-queue";
    public static final String CLIENT_DELETED_QUEUE = "client-deleted-queue";

    @Bean
    public TopicExchange clientExchange() {
        return new TopicExchange(CLIENT_EXCHANGE);
    }

    @Bean
    public Queue clientCreatedQueue() {
        return new Queue(CLIENT_CREATED_QUEUE);
    }

    @Bean
    public Queue clientDeletedQueue() {
        return new Queue(CLIENT_DELETED_QUEUE);
    }

    @Bean
    public Binding bindingClientCreated(Queue clientCreatedQueue, TopicExchange clientExchange) {
        return BindingBuilder.bind(clientCreatedQueue).to(clientExchange).with("client.created");
    }

    @Bean
    public Binding bindingClientDeleted(Queue clientDeletedQueue, TopicExchange clientExchange) {
        return BindingBuilder.bind(clientDeletedQueue).to(clientExchange).with("client.deleted");
    }
}
