package com.empresa.mspersonclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsPersonClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
